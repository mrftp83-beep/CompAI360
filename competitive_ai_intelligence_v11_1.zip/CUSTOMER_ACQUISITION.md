# Zero-Cash Customer Acquisition Engine

## Hard constraint
Until revenue exists, the business does not spend personal money on ads, contractors, paid lead lists, premium SaaS tools, or infrastructure that is not essential.

## Acquisition loop
1. Identify a narrow local-service market.
2. Find businesses using permitted public information.
3. Identify 3–5 plausible competitors.
4. Generate a small, source-backed intelligence preview.
5. Send personalized, compliant outreach or offer the preview through a landing page.
6. Let the prospect see value before paying.
7. Convert the prospect to recurring monitoring.
8. Ask for a referral after the customer receives a useful report.
9. Reinvest only earned revenue into infrastructure or paid acquisition after unit economics are known.

## Channels in order
- Founder-led personalized outreach
- Organic social/community participation
- Referral program
- Agency/consultant partnerships
- Search/SEO content
- Paid acquisition only after revenue validates conversion and customer economics

## Do not do
- Do not buy scraped personal-data lists.
- Do not send bulk spam.
- Do not misrepresent how data was collected.
- Do not expose one customer's private data to another.
- Do not use customer-private material to create prospect reports.
- Do not promise findings that the evidence does not support.

## First milestone
One paying customer. Then prove retention. Then repeat the acquisition process until it is measurable and automatable.
