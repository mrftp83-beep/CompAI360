# First 100 Customers — Bootstrapped Playbook

## Stage 1: 1–10 customers
Pick one vertical. Build a list of 50–100 businesses using public business information. For each, identify a few competitors and prepare a short preview. Prioritize businesses where competitive changes are visible and commercially meaningful.

Goal: learn what customers actually pay for.

## Stage 2: 10–25 customers
Turn the best-performing outreach message into a repeatable template. Add referrals and simple partner outreach to agencies that already serve the target businesses.

Goal: repeatable acquisition without paid ads.

## Stage 3: 25–100 customers
Build organic landing pages, industry-specific examples, a free preview flow, and a lightweight referral loop. Measure visitor → preview → trial → paid → retained.

Goal: establish a measurable acquisition funnel.

## Stage 4: 100+
Only after the business has revenue and retention data should paid acquisition be considered. Every paid channel must have a defined acquisition-cost ceiling and a stop rule.

## Core metrics
- Leads contacted
- Positive responses
- Previews generated
- Trials started
- Paid conversions
- Monthly recurring revenue
- Churn
- Customer acquisition cost
- Gross margin
- Support time per customer

## Operating principle
The product should eventually perform much of the acquisition work itself: prospect qualification → preview → signup → onboarding → monitoring → report → renewal → referral.
