#!/usr/bin/env python3
import argparse, json
from ci_engine.acquisition import lead_score, build_preview, outreach_draft

def main():
    p=argparse.ArgumentParser(description='Generate a no-cost prospect qualification and preview package.')
    p.add_argument('--business',required=True)
    p.add_argument('--website',required=True)
    p.add_argument('--industry',default='')
    p.add_argument('--competitor',action='append',default=[])
    p.add_argument('--finding',action='append',default=[])
    a=p.parse_args()
    score,reasons=lead_score(a.business,a.website,len(a.competitor),a.industry)
    changes=[{'category':'website','summary':x,'evidence':{}} for x in a.finding]
    out={'lead':{'business_name':a.business,'website':a.website,'industry':a.industry,'score':score,'reasons':reasons},
         'preview':build_preview(a.business,a.competitor[0] if a.competitor else 'selected competitors',changes),
         'outreach_draft':outreach_draft(a.business,a.competitor,len(changes))}
    print(json.dumps(out,indent=2))
if __name__=='__main__': main()
