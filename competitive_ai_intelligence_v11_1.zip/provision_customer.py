import argparse, os
from ci_engine.db import connect, upsert_customer, set_customer_api_key
from ci_engine.security import issue_api_key

ap=argparse.ArgumentParser(description='Provision a pilot customer API key')
ap.add_argument('--db',default=os.getenv('CI_DB','ci_intelligence.db'))
ap.add_argument('--name',required=True)
ap.add_argument('--email')
a=ap.parse_args()
c=connect(a.db)
cid=upsert_customer(c,a.name,a.email)
raw,h=issue_api_key(); set_customer_api_key(c,cid,h)
print(f'customer_id={cid}')
print(f'api_key={raw}')
print('Store this key securely. It cannot be recovered from the database.')
