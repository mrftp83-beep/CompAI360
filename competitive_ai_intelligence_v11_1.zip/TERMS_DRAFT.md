# Terms of Service — Draft for Legal Review

Customers may use the service for lawful competitive research and business intelligence.

Customers must not submit information they do not have the right to provide, attempt to access another customer's account, bypass source access controls, or use the service to violate applicable law or third-party rights.

The service may monitor public or licensed information subject to source terms and availability. Collected intelligence can become stale or incomplete; reports should be treated as decision-support information rather than guaranteed facts.

Customer-private data remains customer-specific and is not sold to other customers.

This draft must be reviewed and finalized by counsel before launch.
