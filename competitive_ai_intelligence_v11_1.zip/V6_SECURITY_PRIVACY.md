# V6 Security & Privacy Contract

## Non-negotiable rule
Customer-private data is never sold, exposed, or used as another customer's intelligence context.

## Data classes
- **Public-source intelligence:** permitted public/licensed sources used to monitor competitors.
- **Customer-private:** account data, AI conversations, uploaded material, internal notes, custom rules.
- **Billing secrets:** payment credentials remain with the payment processor; the platform stores subscription/entitlement metadata only.
- **Authentication secrets:** API keys are stored as hashes, never plaintext.

## Tenant isolation
Every customer-owned object is scoped through `customer_id`. Customer API access only returns records belonging to the authenticated tenant. Cross-tenant access must be rejected server-side.

## Privacy controls
- Customer data export endpoint: `GET /export`
- Account deletion endpoint: `DELETE /me`
- Configurable retention days (default 365)
- Audit log for privacy-sensitive actions
- Privacy mode defaults to `private`

## AI boundary
Private customer content is not automatically used to train or enrich a shared model. AI prompts for a customer are assembled only from that customer's authorized context plus permitted external intelligence sources.

## Business model compatibility
We monetize monitoring, analysis, alerts, reports, historical intelligence, and optional modules—not customer-private information.

## Launch note
This is an engineering control set, not a legal certification. Final Terms, Privacy Policy, DPA, retention language, and source-licensing decisions should be reviewed by qualified counsel before commercial launch.
