import json, os, tempfile
from ci_engine.acquisition import build_public_assessment

x=build_public_assessment('Example Co','HVAC',['A/C Pro','Heat Now'],['Pricing','Expansion'])
assert x['business']=='Example Co'
assert x['competitors_entered']==['A/C Pro','Heat Now']
assert x['sample_finding']['status']=='illustrative'
assert 'source URL' in x['sample_finding']['evidence']
print('V9 acquisition assessment: PASS')

from ci_engine.api import Handler
assert os.path.exists('site/index.html')
print('V9 landing page: PASS')
