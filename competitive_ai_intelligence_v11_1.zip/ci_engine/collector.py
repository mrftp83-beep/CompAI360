import hashlib, ipaddress, os, re, socket, urllib.parse, urllib.request, urllib.error, urllib.robotparser
from html.parser import HTMLParser

CONTACT=os.getenv('CI_BOT_CONTACT','support@example.invalid')
UA=f'CompetitiveAIIntelligenceBot/1.0 (+{CONTACT})'
MAX_REDIRECTS=5

class PageParser(HTMLParser):
    def __init__(self): super().__init__(); self.parts=[]; self.title=[]; self.skip=0; self.in_title=False
    def handle_starttag(self,tag,attrs):
        if tag in ('script','style','noscript','svg'): self.skip+=1
        if tag=='title': self.in_title=True
    def handle_endtag(self,tag):
        if tag=='title': self.in_title=False
        if tag in ('script','style','noscript','svg') and self.skip: self.skip-=1
    def handle_data(self,data):
        if self.skip==0:
            d=' '.join(data.split())
            if d:
                self.parts.append(d)
                if self.in_title: self.title.append(d)

def normalize(url):
    p=urllib.parse.urlsplit(url)
    if p.scheme not in ('http','https') or not p.netloc: raise ValueError('Only http/https URLs are supported')
    return urllib.parse.urlunsplit((p.scheme,p.netloc,p.path or '/',p.query,''))

def _host_ips(host):
    try: return [ipaddress.ip_address(host)]
    except ValueError: pass
    return [ipaddress.ip_address(x[4][0]) for x in socket.getaddrinfo(host,None,type=socket.SOCK_STREAM)]

def assert_public_target(url):
    p=urllib.parse.urlsplit(url); host=p.hostname
    if not host: raise ValueError('Missing host')
    if host.lower().endswith('.localhost') or host.lower().endswith('.local'): raise ValueError('Local/internal host targets are blocked')
    if host.lower() in {'localhost','localhost.localdomain'}: raise ValueError('Localhost targets are blocked')
    for ip in _host_ips(host):
        if ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_multicast or ip.is_reserved or ip.is_unspecified: raise ValueError('Private/reserved network targets are blocked')

def robots_for(url):
    p=urllib.parse.urlsplit(url); robots=f'{p.scheme}://{p.netloc}/robots.txt'; req=urllib.request.Request(robots,headers={'User-Agent':UA})
    try:
        with urllib.request.urlopen(req,timeout=10) as r:
            data=r.read(512_000); status=getattr(r,'status',200)
        if 200 <= status < 300:
            rp=urllib.robotparser.RobotFileParser(); rp.parse(data.decode('utf-8','ignore').splitlines()); return rp.can_fetch(UA,url),'ok',robots
        if 400 <= status < 500: return True,'unavailable_4xx',robots
        return False,'unavailable_error',robots
    except urllib.error.HTTPError as e:
        if 400 <= e.code < 500: return True,'unavailable_4xx',robots
        return False,'unavailable_error',robots
    except Exception:
        return False,'unavailable_error',robots

def fetch(url,timeout=15,max_bytes=2_000_000,etag=None,last_modified=None):
    assert_public_target(url)
    headers={'User-Agent':UA,'Accept':'text/html,application/xhtml+xml,application/xml;q=0.9,text/plain;q=0.8,*/*;q=0.5'}
    if etag: headers['If-None-Match']=etag
    if last_modified: headers['If-Modified-Since']=last_modified
    current=url
    for _ in range(MAX_REDIRECTS+1):
        req=urllib.request.Request(current,headers=headers)
        try:
            with urllib.request.urlopen(req,timeout=timeout) as r:
                final=r.geturl(); assert_public_target(final); data=r.read(max_bytes+1); ctype=r.headers.get_content_type(); return data,ctype,final,dict(r.headers.items()),False
        except urllib.error.HTTPError as e:
            if e.code==304: return b'',None,current,dict(e.headers.items()),True
            raise
    raise ValueError('Too many redirects')

def parse_html(data):
    p=PageParser(); p.feed(data.decode('utf-8','ignore')); text=re.sub(r'\s+',' ',' '.join(p.parts)).strip(); title=' '.join(p.title).strip() or (text[:160] if text else '')
    return title,text

def content_hash(text): return hashlib.sha256(text.encode('utf-8')).hexdigest()

def discover(url):
    url=normalize(url); allowed,state,robots=robots_for(url); sources=[{'url':url,'kind':'website','robots_allowed':allowed,'robots_state':state}]
    base=f'{urllib.parse.urlsplit(url).scheme}://{urllib.parse.urlsplit(url).netloc}'
    for path in ('/feed/','/feed.xml','/rss.xml','/atom.xml'):
        u=base+path
        a,s,_=robots_for(u); sources.append({'url':u,'kind':'feed','robots_allowed':a,'robots_state':s})
    return list({x['url']:x for x in sources}.values())

def collect(url,etag=None,last_modified=None,kind='website'):
    url=normalize(url); allowed,state,robots=robots_for(url)
    if not allowed: return {'url':url,'kind':kind,'status':'blocked_robots','text':'','hash':None,'robots_url':robots}
    data,ctype,final,headers,not_modified=fetch(url,etag=etag,last_modified=last_modified)
    if not_modified: return {'url':final,'kind':kind,'status':'not_modified','hash':None,'headers':headers,'robots_url':robots}
    if len(data)>2_000_000: raise ValueError('Response exceeds configured size limit')
    if 'html' in (ctype or '') or final.endswith(('.html','.htm','/')):
        title,text=parse_html(data)
    else: title=final; text=data.decode('utf-8','ignore')
    return {'url':final,'kind':kind,'status':'ok','text':text,'hash':content_hash(text),'title':title,'content_type':ctype,'headers':headers,'robots_url':robots}
