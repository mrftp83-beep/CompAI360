# Launch Readiness Gate

No public rollout until every **BLOCKER** is closed and evidence is recorded.

## Product
- [ ] BLOCKER: signup/login/email verification/password reset work in staging
- [ ] BLOCKER: onboarding reaches first meaningful result
- [ ] BLOCKER: empty/loading/error/permission states are polished
- [ ] BLOCKER: mobile and desktop smoke tests pass
- [ ] BLOCKER: tenant isolation passes with two synthetic customers
- [ ] BLOCKER: cancellation and account deletion work

## Data & intelligence
- [ ] BLOCKER: permitted source list and collection rules documented
- [ ] BLOCKER: material findings have source URL/date/evidence
- [ ] BLOCKER: fact vs inference is clearly labeled
- [ ] BLOCKER: source failures never become fabricated findings

## Security & infrastructure
- [ ] BLOCKER: HTTPS/custom domain active
- [ ] BLOCKER: secrets are outside source control
- [ ] BLOCKER: auth endpoints are rate limited
- [ ] BLOCKER: dependency/security scan reviewed
- [ ] BLOCKER: backups and restore test completed
- [ ] HIGH: security headers/CSP reviewed

## Billing
- [ ] BLOCKER: Stripe sandbox end-to-end test passes
- [ ] BLOCKER: webhook signatures verified and handlers idempotent
- [ ] BLOCKER: entitlements are webhook-driven
- [ ] BLOCKER: upgrade/downgrade/cancel/failed-payment flows tested
- [ ] BLOCKER: pricing page matches Stripe configuration

## Trust & legitimacy
- [ ] BLOCKER: real legal entity/company information published
- [ ] BLOCKER: privacy policy matches actual data practices
- [ ] BLOCKER: terms of service published
- [ ] BLOCKER: refund/cancellation policy published
- [ ] BLOCKER: real support email on verified company domain
- [ ] HIGH: security/trust page published
- [ ] HIGH: subprocessors listed
- [ ] HIGH: status/incident communication process established

## Email & web
- [ ] BLOCKER: SPF/DKIM/DMARC configured
- [ ] BLOCKER: all transactional links use production HTTPS
- [ ] BLOCKER: no localhost/example.com/staging/placeholder links remain
- [ ] HIGH: sitemap, robots.txt, canonical URLs and OG metadata verified

## Operations
- [ ] BLOCKER: uptime/error monitoring active
- [ ] BLOCKER: background-job failure alerts active
- [ ] BLOCKER: Stripe webhook failures monitored
- [ ] BLOCKER: rollback procedure tested
- [ ] HIGH: customer support process established

## Final release test
Two synthetic customers: signup -> verify -> onboarding -> add competitor -> collect -> detect change -> finding -> report -> sandbox checkout -> entitlement -> cancel -> deletion. Record results before inviting real customers.
