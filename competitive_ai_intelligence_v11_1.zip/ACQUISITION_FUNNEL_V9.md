# Acquisition Funnel V9

## Funnel
1. Prospect sees a useful competitive-intelligence message.
2. Prospect opens the free assessment.
3. Prospect enters business + optional competitors + priorities.
4. Assessment demonstrates the monitoring categories and evidence model without pretending to have observed facts.
5. Prospect is invited to activate continuous monitoring.
6. Paid customer selects a plan and competitor limit.
7. Customer receives recurring intelligence and can add modules.

## First-customer operating loop
- Build a small list of legitimate prospects in one vertical.
- Review each prospect manually enough to avoid irrelevant outreach.
- Generate a tailored preview/assessment.
- Send a concise, permission-aware outreach message.
- Record status in the lead CRM.
- Follow up only where appropriate and permitted.
- Convert interested prospects into a pilot.
- Measure activation, retention, report usefulness and willingness to pay.

## Metrics
Track:
- prospects contacted
- assessments generated
- responses
- demos/pilots
- paid conversions
- monthly recurring revenue
- churn
- average competitors monitored
- module attach rate
- report open/use rate
- cost per acquired customer

## Zero-cash rule
No paid acquisition until customer revenue can fund it and the economics are demonstrated.
