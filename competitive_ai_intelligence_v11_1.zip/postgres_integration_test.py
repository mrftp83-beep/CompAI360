"""CompAI360 PostgreSQL integration test.

Requires CI_POSTGRES_DSN pointing to a disposable PostgreSQL database.
Run with: CI_POSTGRES_DSN='postgresql://...' python postgres_integration_test.py
"""
import os
if not os.getenv('CI_POSTGRES_DSN'):
    print('POSTGRES INTEGRATION TEST SKIPPED: CI_POSTGRES_DSN is not set')
    raise SystemExit(0)
from ci_engine.db import connect, upsert_customer, upsert_competitor, upsert_source, enqueue, is_postgres
from ci_engine.worker import claim, recover_stale_jobs, generate_reports

c=connect()
assert is_postgres(c), 'Expected PostgreSQL connection'
name='V11 PG Test'
email='v11-pg-test@example.invalid'
c.execute('DELETE FROM customers WHERE email=%s',(email,)); c.commit()
cid=upsert_customer(c,name,email)
comp=upsert_competitor(c,'PG Competitor','https://example.invalid',cid)
sid=upsert_source(c,comp,'https://example.invalid','website',False,'blocked_robots')
jid=enqueue(c,'report',{'customer_id':cid})
recover_stale_jobs(c)
job=claim(c)
assert job and job['id']==jid and job['status']=='running'
# Exercise the report path and PostgreSQL parameter binding.
result=generate_reports(None,cid)  # connect() uses CI_POSTGRES_DSN
assert result['reports_created']==1
c.execute('DELETE FROM reports WHERE customer_id=%s',(cid,)); c.execute('DELETE FROM sources WHERE competitor_id=%s',(comp,)); c.execute('DELETE FROM competitors WHERE customer_id=%s',(cid,)); c.execute('DELETE FROM jobs WHERE id=%s',(jid,)); c.execute('DELETE FROM customers WHERE id=%s',(cid,)); c.commit()
print('POSTGRES INTEGRATION TEST PASSED')
