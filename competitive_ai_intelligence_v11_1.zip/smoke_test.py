import os, tempfile
from ci_engine.db import connect, upsert_customer, upsert_competitor, upsert_source, enqueue
from ci_engine.worker import worker_loop
with tempfile.TemporaryDirectory() as d:
    db=os.path.join(d,'test.db'); c=connect(db)
    cid=upsert_customer(c,'Smoke Test','smoke@example.invalid'); comp=upsert_competitor(c,'Test Competitor','https://example.invalid',cid); sid=upsert_source(c,comp,'https://example.invalid','website',False,'blocked_robots'); jid=enqueue(c,'monitor_source',{'source_id':sid})
    assert jid and c.execute('select count(*) n from jobs').fetchone()['n']==1
    worker_loop(db,once=True)
    assert c.execute('select status from jobs where id=?',(jid,)).fetchone()['status'] in ('done','queued','failed')
print('SMOKE TEST PASSED')
