# Data-source policy

1. Prefer first-party websites, public government datasets, official RSS/Atom feeds, and licensed APIs/data providers.
2. Store source URL, observation timestamp, provider, collection method, and license/terms reference.
3. Do not collect authentication-protected or access-controlled material without authorization.
4. Honor robots directives as a technical crawl-control requirement and keep conservative rate limits.
5. Minimize personal data. Competitive intelligence should focus on business-level facts, not profiles of private individuals.
6. AI outputs must distinguish observed facts from inference and retain evidence links.
7. Every new source type must pass a source-specific terms/licensing review before being enabled for paying customers.
