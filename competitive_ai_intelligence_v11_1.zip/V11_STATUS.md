# CompAI360 V11 — Production Foundation

V11 is focused on moving the core runtime toward a portable production deployment without spending money or outsourcing development.

## Completed in this build
- Added PostgreSQL-capable database backend selected by `CI_POSTGRES_DSN`.
- Kept SQLite as the local fallback so existing development/tests continue to work.
- Added PostgreSQL schema creation and compatibility for core customer, competitor, source, observation, change, report, lead, billing, webhook, audit, and job tables.
- Updated monitoring to use the database backend rather than opening SQLite directly.
- Updated the worker job claim path for PostgreSQL row locking (`FOR UPDATE SKIP LOCKED`) while preserving SQLite behavior.
- Added one-time `migrate_sqlite_to_postgres.py` migration utility.
- Added `docker-compose.postgres.yml` for local end-to-end PostgreSQL testing.
- Added `psycopg` dependency.
- Added `CI_POSTGRES_DSN` to `.env.example`.
- Existing SQLite smoke, security, and V9 acquisition tests pass.

## Next production-foundation work
1. Run the PostgreSQL compose stack and exercise API + worker against it.
2. Add an automated PostgreSQL integration test path.
3. Harden outbound collection further (timeouts, DNS/rebinding considerations, redirect policy, content-type/size controls, rate limiting).
4. Add production scheduler configuration and worker observability.
5. Prepare provider-specific deployment manifests only after the portable stack passes end-to-end.
6. Perform a live permitted-source collection test from a hosted environment.

## Important
This is not a claim that CompAI360 is production-ready yet. A real launch still requires production secrets, HTTPS/domain, durable backups, email, monitoring, production Stripe configuration, production AI provider configuration, source/provider licensing review, and legal review of the final policies.

## V11.1 PostgreSQL hardening
- Fixed PostgreSQL parameter binding in worker/report paths.
- Fixed PostgreSQL parameter binding in API customer/report/lead/billing paths.
- Fixed PostgreSQL parameter binding in privacy-retention cleanup.
- Added `postgres_integration_test.py` for execution against a disposable PostgreSQL DSN.
- Local SQLite smoke, security, and acquisition tests pass after changes.
- The actual PostgreSQL integration test is intentionally skipped in this build environment because no PostgreSQL server is available; it must be run once a PostgreSQL instance is provisioned.
