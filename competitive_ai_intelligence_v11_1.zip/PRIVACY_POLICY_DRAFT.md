# Privacy Policy — Draft for Legal Review

We collect and process information needed to provide the Competitive AI Intelligence service, including account information, configuration, monitoring targets, service usage, and customer-provided content.

We do not sell customer-private information to other customers. Customer-private information is logically separated by account and is not intentionally exposed across accounts.

Competitive intelligence is generated from permitted public or licensed sources. Source collection is subject to applicable access rules, contracts, licenses, and source terms.

Customers can request export or deletion of their account data, subject to legally required retention.

Payment credentials are handled by our payment processor; our application should receive only the billing information necessary to manage subscriptions and entitlements.

We may use aggregated, de-identified operational statistics where permitted, but we do not use one customer's private business information as another customer's intelligence.

This draft must be reviewed and finalized by counsel before launch.
