# Billing implementation plan

Use Stripe Billing + Checkout Sessions for recurring subscriptions. Use a separate Stripe sandbox during development. Subscription state must be synchronized from Stripe webhooks; the success page is not the source of truth for fulfillment.

Initial products:
- Starter: base subscription + 5 competitors
- Growth: base subscription + 15 competitors
- Pro: base subscription + 50 competitors

Metered/add-on dimensions can later include extra competitors, daily monitoring, and intelligence modules. Do not activate live billing until authentication, customer isolation, webhook verification, cancellation, and entitlement checks are implemented.
