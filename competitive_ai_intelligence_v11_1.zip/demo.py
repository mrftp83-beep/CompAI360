from ci_engine.collector import collect
r=collect('https://example.com/')
print('status:',r['status']); print('hash:',r['hash']); print('preview:',r['text'][:300])
