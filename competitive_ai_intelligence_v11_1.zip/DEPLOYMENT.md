# Production deployment path

## 1. Infrastructure
Use a managed HTTPS reverse proxy/WAF in front of the API. Run the API and worker separately. For the first paid pilot, a managed container host plus managed PostgreSQL is sufficient; do not expose the database to the public internet.

## 2. Secrets
Set environment variables from `.env.example` through the host's secret manager. Never commit `.env`, Stripe keys, API keys, webhook secrets, or customer exports.

Stripe: use a separate Stripe sandbox for development and CI. Use a restricted API key (`rk_`) in production where its permissions are sufficient. Stripe Checkout handles payment collection; the application does not store card details.

## 3. Billing
Create separate Stripe Products for Starter, Growth, and Pro, with their own recurring Prices. Put the resulting Price IDs in `STRIPE_PRICE_STARTER`, `STRIPE_PRICE_GROWTH`, and `STRIPE_PRICE_PRO`.

Register `/stripe/webhook` and verify signatures using `STRIPE_WEBHOOK_SECRET`. Subscription access is driven by webhook state, not by the Checkout success page.

Before enabling automatic tax collection, complete Stripe Tax registration/setup for the jurisdictions where tax must be collected.

## 4. Data
For the first pilot, SQLite is acceptable for local/single-node testing only. Before opening the service broadly, migrate the authoritative store to managed PostgreSQL and keep encrypted backups with tested restores.

## 5. Go-live checks
- HTTPS enforced
- WAF/rate limiting enabled
- API/admin secrets rotated from test values
- Stripe sandbox tests pass, then live-mode test transaction
- Webhook signature and replay tests pass
- Cross-tenant tests pass
- Backup restore tested
- Privacy/Terms reviewed by qualified counsel
- Source collection reviewed against provider terms/licensing
- Error monitoring and uptime alerting enabled
