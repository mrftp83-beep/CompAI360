# Competitive AI Intelligence Engine — V6.1

V5 turns the prototype into a production-oriented monitoring core.

## Built in V5
- SQLite schema with customers, competitors, sources, observations, changes, findings, reports, alerts, and jobs.
- Safer public-web collection with robots handling, SSRF/private-network blocking, redirect limits, response-size limits, and conditional GET support (ETag/Last-Modified).
- RSS/Atom collection wired into monitoring.
- Structured signal extraction for pricing, promotions, services, hiring, and locations.
- Provider-neutral LLM adapter (`ci_engine/llm.py`) with no credentials in source.
- Background worker with queued jobs, retries, report generation, and failure tracking.
- Docker/Docker Compose deployment skeleton.
- Minimal API for health and competitor listing.

## Run locally
```bash
python -m ci_engine.run --name "Example Competitor" --website "https://example.com" --db ci_intelligence.db
python -m ci_engine.scheduler --db ci_intelligence.db --hours 24
python -m ci_engine.worker --help
```

## Production requirements still outstanding
1. Hosted outbound-network environment.
2. Real authentication/customer isolation.
3. LLM provider credentials and a strict structured-output adapter.
4. Licensed/provider adapters for reviews, hiring, advertising, news, and business datasets where permitted.
5. Email/alert delivery.
6. Stripe Checkout + Billing + webhooks and entitlement enforcement.
7. Monitoring/logging/secrets management.

This repository intentionally does not claim that live collection is running continuously. Deployment and credentials are required for that.

## Data access
Robots.txt is only one control. Production collection must also respect applicable terms, contracts, privacy requirements, copyright, authentication/access controls, and provider licensing.

## V6.1 security/privacy + billing layer
Customer-private information is tenant-scoped and is not sold or exposed to other customers. API credentials are hashed. The API includes customer-scoped export/deletion controls, audit logging, retention controls, and security headers. See `V6_SECURITY_PRIVACY.md`, `PRIVACY_POLICY_DRAFT.md`, `TERMS_DRAFT.md`, and `V6_STATUS.md`.


## V6.1 operational additions
- Optional Stripe Billing Checkout and verified webhook processing.
- Subscription state stored separately from customer-private intelligence data.
- Idempotent webhook event handling.
- Production deployment and go-live checklists.

See `DEPLOYMENT.md` and `OPERATIONAL_CHECKLIST.md`.

## V7 customer-facing pilot

The V7 pilot adds a browser dashboard at `/dashboard`, authenticated by the customer's private API key, plus customer-scoped competitor creation, monitoring queueing, report viewing, and data export. The worker must be running for queued monitoring/report jobs to execute. Do not use SQLite for a multi-instance production deployment; migrate to PostgreSQL before opening the service broadly.
