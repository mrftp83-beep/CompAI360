"""Migrate a CompAI360 SQLite database into PostgreSQL.

Usage:
  CI_POSTGRES_DSN='postgresql://...' python migrate_sqlite_to_postgres.py --sqlite ci_intelligence.db

The destination schema is created by ci_engine.db.connect(). Existing PostgreSQL
rows are not overwritten. This is intended for a one-time pilot migration.
"""
import argparse, os, sqlite3
from ci_engine.db import connect, is_postgres

TABLES = [
    'customers','competitors','sources','observations','changes','findings',
    'reports','alert_rules','jobs','audit_log','billing','webhook_events','leads'
]

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--sqlite',required=True); args=ap.parse_args()
    if not os.getenv('CI_POSTGRES_DSN'):
        raise SystemExit('CI_POSTGRES_DSN is required')
    src=sqlite3.connect(args.sqlite); src.row_factory=sqlite3.Row
    dst=connect();
    if not is_postgres(dst): raise SystemExit('Destination is not PostgreSQL')
    for table in TABLES:
        rows=src.execute(f'SELECT * FROM {table}').fetchall()
        if not rows: continue
        cols=[d[0] for d in src.execute(f'SELECT * FROM {table} LIMIT 0').description]
        placeholders=','.join(['%s']*len(cols))
        colsql=','.join(cols)
        for row in rows:
            values=[row[c] for c in cols]
            # Preserve IDs during migration and skip records already present.
            dst.execute(f'INSERT INTO {table} ({colsql}) VALUES ({placeholders}) ON CONFLICT DO NOTHING', values)
        dst.commit()
        print(f'{table}: {len(rows)} rows processed')
    # Restore BIGSERIAL sequences after preserving source IDs.
    for table in TABLES:
        if table in {'billing','webhook_events'}: continue
        try:
            dst.execute(f"SELECT setval(pg_get_serial_sequence('{table}','id'), COALESCE((SELECT MAX(id) FROM {table}),1), true)")
        except Exception:
            dst.rollback()
    dst.commit(); src.close(); dst.close(); print('Migration complete.')

if __name__=='__main__': main()
