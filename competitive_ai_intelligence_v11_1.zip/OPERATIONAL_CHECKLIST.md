# Operational checklist

## Ready in the current V6.1 build
- Customer-scoped API keys
- Tenant isolation
- Export/delete controls
- Audit logging
- Retention fields
- Security headers
- Stripe Checkout endpoint (configuration required)
- Stripe webhook verification and subscription-state persistence
- Idempotent webhook event handling
- Docker deployment skeleton

## Must be completed before accepting general-public customers
- Managed PostgreSQL
- Production authentication/MFA or a hosted identity provider
- HTTPS/WAF/rate limiting
- Email delivery and report scheduling
- Real LLM provider + structured-output validation
- Source-provider licensing/terms review
- Monitoring/error tracking
- Encrypted backups + restore drill
- Legal review of Privacy Policy, Terms and data-processing commitments
- Customer-facing dashboard/onboarding
