import os, tempfile, urllib.request, urllib.error, threading, time
from ci_engine.db import connect, upsert_customer, upsert_competitor, set_customer_api_key
from ci_engine.security import issue_api_key
from ci_engine.api import serve

with tempfile.TemporaryDirectory() as d:
    db=os.path.join(d,'test.db'); os.environ['CI_DB']=db; os.environ['CI_API_KEY']='unused'
    c=connect(db)
    a=upsert_customer(c,'A','a@example.invalid'); b=upsert_customer(c,'B','b@example.invalid')
    ca,_=issue_api_key(); cb,_=issue_api_key()
    from ci_engine.security import hash_secret
    set_customer_api_key(c,a,hash_secret(ca)); set_customer_api_key(c,b,hash_secret(cb))
    upsert_competitor(c,'A Competitor','https://a.example',a)
    upsert_competitor(c,'B Competitor','https://b.example',b)
    t=threading.Thread(target=serve,args=(18765,),daemon=True); t.start(); time.sleep(.2)
    def get(key,path):
        req=urllib.request.Request('http://127.0.0.1:18765'+path,headers={'Authorization':'Bearer '+key})
        return urllib.request.urlopen(req,timeout=2).read().decode()
    assert 'A Competitor' in get(ca,'/competitors')
    assert 'B Competitor' not in get(ca,'/competitors')
    assert 'B Competitor' in get(cb,'/competitors')
    print('SECURITY TEST PASSED: tenant isolation enforced')
